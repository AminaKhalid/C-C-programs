
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// function prototypes
void movejockeyA( int *jockeyA);
void movejockeyB (int *jockeyB);
void printCurrentPositions(unsigned int, unsigned int);

int main()
{ 
   srand(time(NULL));

   unsigned int jockeyA = 1; // jockeyA current position
   unsigned int jockeyB = 1; // jockeyB  current position      
   unsigned int counter = 0; // counter for the for loop controling the race.

 
   puts("The Race has started");
   
   // loop through the progress on the track
   while (jockeyA != 100 && jockeyB != 100) 
   { //neither horse has reached the end of the track
     //^^call functions to move horses on the track and print current positions
      
      movejockeyA(&jockeyA);
	  movejockeyB(&jockeyB);
	  printCurrentPositions(jockeyA, jockeyB);
	  
      ++counter;
   } 

   // determine the winner and print message - one horse/jockey has passed the end as it is outside the loop.
   if (jockeyA > jockeyB) 
   {
      printf("\nJockey A wins");
   } 
             
   if (jockeyA < jockeyB) 
   {
      printf("\nJockey B wins");
   }
	if (jockeyA == jockeyB)
   {
     printf("\nIt's a tie\n"); 
   } 
   
   printf("\niteration: %u", counter);
} 

// progress for Jockey B
void movejockeyB( int *jockeyBPtr)
{ 
	int x;
    // ^^generate random number from 1-10 - make sure it is different each time program is run.
   x = 1 + rand()%10;
   printf("Jockey B random : %d \n", x);
   // determine progress
   if (x >= 1 && x <= 5) 
   { // full speed 50% of the time
      *jockeyBPtr += 2;
   } 
   //^^Test all the rules from the specification.
   if (x == 6)	//option B
   {
	   *jockeyBPtr ++;
   }
   if (x == 7)	//option C
   {
	   *jockeyBPtr = *jockeyBPtr + 3;
   }
   if (x == 8)	//option D
   {
	   *jockeyBPtr = *jockeyBPtr;
   }
   if (x == 9 || x == 10)	//option E
   {
	   *jockeyBPtr = *jockeyBPtr - 2;
   }
   // check boundaries
   
   if (*jockeyBPtr < 1) 
   {
      *jockeyBPtr = 1;
   } 
   if (*jockeyBPtr > 100) 
   {
      *jockeyBPtr = 100;
   } 
} 

// progress for the Jockey A
void movejockeyA( int *jockeyAPtr)
{ 
	int x;
    x = 1 + rand()%10;
   printf("Jockey A random : %d \n", x);
   // determine progress
   if (x >= 1 && x <= 5) 
   { // full speed 50% of the time
      *jockeyAPtr += 2;
   } 
   //^^Test all the rules from the specification.
   if (x == 6)
   {
	   *jockeyAPtr ++;
   }
   if (x == 7)
   {
	   *jockeyAPtr = *jockeyAPtr + 3;
   }
   if (x == 8)
   {
	   *jockeyAPtr = *jockeyAPtr;
   }
   if (x == 9 || x == 10)
   {
	   *jockeyAPtr = *jockeyAPtr - 2;
   }
   // check boundaries
   
   if (*jockeyAPtr < 1) 
   {
      *jockeyAPtr = 1;
   } 
   if (*jockeyAPtr > 100) 
   {
      *jockeyAPtr = 100;
   } 
}

// display new position each time there is a move.
void printCurrentPositions(unsigned int jockeyA, unsigned int jockeyB)
{ 
    // loop through race
   for (unsigned int count = 1; count <= 100; ++count) 
   {
      // print current leader
        
      if (count == jockeyA && count == jockeyB) 
	  {
         printf("%s",  "Tie!!");
		 printf("\nthe postion of jockeyA and jockeyB is: %d", count);
		 break;
      } 
      else if (count == jockeyB) 
	  {
		  printf("Jockey A is ahead");
		  printf("\nthe position of jockeyA is: %d", jockeyA);
  		  printf("\nthe position of jockeyB is: %d", jockeyB);
		  break;
      } 
      else if (count == jockeyA) 
	  {
		  printf("Jockey B is ahead");
		  printf("\nthe position of jockeyA is: %d", jockeyA);
		  printf("\nthe position of jockeyB is: %d", jockeyB);
		  break;
      } 
      else 
	  {
        //^^implement what should happen in this case (print a space)
      } 
   }

   puts("\n");
} 


