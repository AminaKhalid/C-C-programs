/*Write a C Program which prompts the user to enter 4 integers. It should then sum the
integers and multiply the integers, storing the results in suitable variables. The program
should print each integer value (including the results) and the memory address where each
integer is stored. The program should also include a function which squares each of the 4
integers using pass by reference.*/
#include <stdio.h>

void squarebyReference(int *nPtr);	//prototype
int main (void)
{
	//initialize variables to 0
	int a=0, b=0, c=0, d=0;
	int sum;
	int multiply;
	//set a, b, c and d pointers to their addresses
	int *aPtr = &a;
	int *bPtr = &b;
	int *cPtr = &c;
	int *dPtr = &d;
	
	//user input
	printf("\nEnter an integer for a: ");
	scanf("%d", &a);
	
	printf("\nEnter an integer for b: ");
	scanf("%d", &b);
	
	printf("\nEnter an integer for c: ");
	scanf("%d", &c);
	
	printf("\nEnter an integer for d: ");
	scanf("%d", &d);
	//calculating sum
	sum = a+b+c+d;
	printf("\nthe sum is: %d", sum);
	//calculating product
	multiply = a*b*c*d;
	printf("\nthe multiplication is: %d", multiply);
	
	//print the addresses of numbers
	printf("\nthe address of %d is %p \n", a, &a);
	printf("\nthe address of %d is %p \n", b, &b);
	printf("\nthe address of %d is %p \n", c, &c);
	printf("\nthe address of %d is %p \n", d, &d);
	
	//pass addresses of numbers to squarebyReference
	squarebyReference(&a);
	printf ("\nThe square is: %d", a);
	
	squarebyReference(&b);
	printf ("\nThe square is: %d", b);
	
	squarebyReference(&c);
	printf ("\nThe square is: %d", c);
	
	squarebyReference(&d);
	printf ("\nThe square is: %d", d);
	
}
//calculating square of *nPtr
void squarebyReference(int *nPtr)
{
	*nPtr = *nPtr * *nPtr;	//square *nPtr
}
