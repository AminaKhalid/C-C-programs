/*Write a C Program to demonstrate the address structure in arrays. The program should
create 2 arrays of different numeric types (integer and float) and then print the address of
each element of each array to the screen. Format the output so that it is easy to
understand. You should notice that the gap between addresses is equal to the size in bytes
of the type of the array.*/

#include <stdio.h>
int main(void)
{
	//declare variables
	int i, j, k;
	//to enter the size of the array
	printf("Enter the size of arrayA: ");
	scanf("%d", &j);
	printf("Enter the size of arrayB: ");
	scanf("%d", &k);
	
	//declare arrays of different numeric types
	int arrayA[j];
	float arrayB[k];
	int *APtr = &arrayA[j];
	int *BPtr = &arrayA[k];
	int m;
	
	//print each value of arrayA and the address of that value
	printf("\nThe values of arrayA: ");
	for (i=0; i<j; i++)
	{
		scanf("\n%d", &arrayA[i]);
		printf("\nThe address of %d is: %p\n", arrayA[i], &arrayA[i]);
	}
	//print each value of arrayB and the address of that value
	printf("\nThe values of arrayB: ");
	for (m=0; m<k; m++)
	{
		scanf("\n%f", &arrayB[m]);
		printf("\nThe address of %f is: %p\n", arrayB[m], &arrayB[m]);
	}
	
}
