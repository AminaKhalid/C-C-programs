/*Write a C Program to demonstrate pointers to functions. The program should contain three
functions: reverseArray, randomiseArray and printArray. The function prototypes and array
initialisation are given below:
void reverseArray(int arraySize, int a[]);
void randomiseArray(int arraySize, int a[]);
void printArray(int arraySize, int a[], void (*arrayFunction)(int arraySize, int a[]));
int myArray = {2,4,6,8,10,12,14,16,18,20};
reverseArray should swap reverse the order of all elements in an array; randomiseArray should
randomly mix the order of elements in an array; printArray should print the contents of the array
in reverse order or random order depending on user input. See lecture notes for examples.*/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

//function declarations;
void reverseArray(int arraySize, int a[]);
void randomiseArray(int arraySize, int a[]);
void printArray(int arraySize, int a[], void (*arrayFunction)(int arraySize, int a[]));

int main (void)
{
	//to randomise the array
	srand(time(NULL));
	int i;
	int myArray[] = {2,4,6,8,10,12,14,16,18,20};
	int choice;
	//print the original array
	printf("Original array: ");
	for (i=0; i<10; i++)
	{
		printf("%d ", myArray[i]);
	}
	
	//choice for user
	printf("\n\nPress 1 to reverseArray or press 2 to randomiseArray: ");
	scanf("%d", &choice);
	
	//if choice is 1 then go to reverse Array function
	if(choice == 1)
	{
		printArray(10, myArray, reverseArray);
	}
	//if choice is 2 then go to randomise Array function
	else if (choice == 2)
	{
		printArray(10, myArray, randomiseArray);
	}
}
//reverseArray function 
void reverseArray(int arraySize, int a[])
{
	int myArray;
	int i;
	int swap;
	//swapping the last element of array with the first one
	for (i=0;i<arraySize/2;i++)
	{
		swap = a[i];
		a[i] = a[arraySize-i-1];
		a[arraySize-i-1] = swap;
	}
	
}
//randomiseArray function
void randomiseArray(int arraySize, int a[])
{
	int myArray;
	int temp;
	int i, j;
	for (i = arraySize; i >= 0; i--)
	{
		//rand () to randomise the array
		j = rand() % (i + 1);
		temp = a[j];
		a[j] = a[arraySize-1];
		a[arraySize-1] = temp;
	}
	
}
//print the array function
void printArray(int arraySize, int a[], void (*arrayFunction)(int arraySize, int a[]))
{
	(*arrayFunction)(arraySize, a);
	int i;
	
	for (i=0; i<10; i++)
	{
		printf ("%d ", a[i]);
	}
	
	
}