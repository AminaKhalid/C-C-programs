#include <stdio.h>
#include <math.h>
//function prototypes
void function1(int a, int b);
void function2(int a, int b);
void function3(int a, int b);
void function4(int a, int b);
void function5(int a, int b);
void function6(int a, int b);

int main (void)
{
	/*initialise array of 6 pointers to functions that take an
	int argument and return void*/
	int a, b;
	void (*f[6])(int, int) = { function1, function2, function3, function4, function5, function6 };
	
	printf("enter integer for a: ");
	scanf("%d", &a);
	printf("enter integer for b: ");
	scanf("%d", &b);
	//user's choice
	printf ("%s", "\npress 0 for addition, 1 for multiplication, 2 for subtraction, 3 for division, 4 for modulo, 5 for power: ");
	size_t choice;
	scanf("%u", &choice);
	//to process user's choice
	while (choice>=0 && choice<6)
	{
		//invoke function at the location of choice
		(*f[choice])(a, b);
	
	break;
	}
	
}
//add function
void function1(int a, int b)
{
	int add;
	add = a + b;
	printf("\naddition: %d", add);
	
}
//multiplication function
void function2(int a, int b)
{
	int multiplication;
	multiplication = a * b;
	printf("\nmultiplication: %d", multiplication);
}
//subtraction function
void function3(int a, int b)
{
	int subtraction;
	subtraction = a - b;
	printf("\nsubtraction: %d", subtraction);
} 
//division function
void function4(int a, int b)
{
	double x, y;
	x=a;
	y=b;
	int division;
	division = a / b;
	printf ("\ndivision: %d", division);
}
//mod function
void function5(int a, int b)
{
	int mod;
	mod = a % b;
	printf("\nmodlulus: %d", mod);
}
//power function
void function6(int a, int b)
{
	int power;
	power = pow (a, b);
	printf("\na to the power of b: %d", power);
}