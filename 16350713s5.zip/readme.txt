
I used the gcc compiler
example:

gcc s5q1.c -o s5q1.exe
s5q1.exe