#include <stdio.h>

int main(void)
{
    int A[10][10], B[10][10], result[10][10];
	int r1, c1;
	int r2, c2;
	int i,j,r;
	
    printf("Enter rows and column for first matrix: ");
    scanf("%d %d", &r1, &c1);

    printf("Enter rows and column for second matrix: ");
    scanf("%d %d",&r2, &c2);
	
	while (c1!=r2)
	{
		printf("Error\n");
		printf("Enter rows and column for first matrix: ");
		scanf("%d %d", &r1, &c1);

		printf("Enter rows and column for second matrix: ");
		scanf("%d %d",&r2, &c2);
	}
	
	// Storing elements of first matrix.
    printf("Enter the elements of matrix 1: \n");
	for (i=0;i<r1;++i)
	{
		for (j=0;j<c1;++j)
		{
			printf("Enter Elements: ");
			scanf("%d", &A[i][j]);
		}
	}
	// Storing elements of second matrix.
	printf("Enter the elements of matrix 2: \n");
	for (i=0;i<r2;++i)
	{
		for (j=0;j<c2;++j)
		{
			printf("Enter elements: ");
			scanf("%d", &B[i][j]);
		}
	}
	// Initializing all elements of result matrix to 0
    for(i=0; i<r1; ++i)
        for(j=0; j<c2; ++j)
        {
            result[i][j] = 0;
        }
	// multiplying A and B
	for (i=0;i<r1;++i)
	{
		for (j=0;j<c2;++j)
		{
			for (r=0;r<c1;++r)
			{
				result[i][j]=result[i][j]+A[i][r]*B[r][j];
			}
		}
	}
	// Displaying the result
    for(i=0; i<r1; ++i)
	{
		for(j=0;j<c2; ++j)
		{
			printf("%d ", result[i][j]);
		}
		printf("/n")
	}		
    
           
    return 0;
}
