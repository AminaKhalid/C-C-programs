/*You work in an insurance company, you have installed trackers into several of your
customers’ cars in order to monitor their driving and offer a discount if they are ‘good’
drivers. Write a C Program that creates a two-dimensional array to record the average daily
acceleration of 5 of your customers over the past 10 trips. The data are shown below. The 
program should prompt you (the user) for a driver number and then return the data of that
driver along with a summary of the data and some advice regarding the discount. If the total
average acceleration is more than 5 or more OR any single trip average is more 6 or more,
then no discount should be applied to the customer. For example, if the user enters 1 the
program responds with:	Driver 1 Summary:
Acceleration Recordings: 3,1,3,4,6,7,3,2,5,3
Max average acceleration for Driver 1 was in trip 7
Average acceleration over all of Driver 1 trips: 3.7
Discount: No Discount to be applied
The average acceleration of all drivers over all trips is: 3.46
Driver data:
Driver 1 – 3, 1, 3, 4, 6, 7, 3, 2, 5, 3
Driver 2 – 2, 2, 2, 3, 4, 4, 3, 3, 3, 2
Driver 3 – 5, 6, 7, 6, 5, 3, 3, 3, 3, 3
Driver 4 – 3, 3, 3, 3, 4, 4, 3, 2, 1, 3
Driver 5 – 2, 3, 4, 6, 6, 2, 5, 1, 3, 3*/

#include <stdio.h>
#define CUSTOMERS 5
#define TRIPS 10

//function prototypes
int maxav(const int customerdata[][CUSTOMERS], size_t customer, size_t trips);
double average(const int setOfdata[], size_t trips);

int main (void)

{
	int i, j, customer;
	//initialize the acceleration for 5 drivers (rows)
	int customerdata[CUSTOMERS][TRIPS] = 
		{{3, 1, 3, 4, 6, 7, 3, 2, 5, 3},
		{2, 2, 2, 3, 4, 4, 3, 3, 3, 2},
		{5, 6, 7, 6, 5, 3, 3, 3, 3, 3},
		{3, 3, 3, 3, 4, 4, 3, 2, 1, 3},
		{2, 3, 4, 6, 6, 2, 5, 1, 3, 3}};
	
	
	for(i=0;i<CUSTOMERS;i++)
	{
		for (j=0;j<TRIPS;j++)
		{
			printf("%d\t", customerdata[i][j]);
		}
		printf("\n");
	}
	//print the driver's data, depending on the number if the driver
	printf("Enter the driver's number: \n");
	scanf("%d", &customer);
	
	for (i=0;i<TRIPS;i++)
	{
		printf("%d ", customerdata[customer-1][i]);
	}
	//determine the max average acceleration for the driver
	printf("Max average acceleration for driver %d was in trip %d\n", maxav(customer, TRIPS));
	
	//determine the average for the acceleration of the driver
	for(size_t driver=0; driver < CUSTOMERSl driver++)
	{
		printf("Average acceleration for Driver %d: %lf", driver, average(customerdata[driver], TRIPS) );
	}
	
	return 0;
}
//find the max average
int maxav(const int customerdata[][CUSTOMERS], size_t customer, size_t trips)
{
	
int maxaverage = 0;
int i;
//loop throught the rows
for(size_t i=0; i<CUSTOMERS; i++)
	{
		
		if (customerdata[customer][i] > maxaverage)
		{
			maxaverage = customerdata[customer][i];
		}
		
	}

	return maxaverage;	//return maximum acceleration
}
//determining the average acceleration for the driver
double average(const int setOfdata[], size_t trips)
{

	int total =0;
	//total all acceleration values
	for(size_t i =0; i<trips; i++)
	{
		totalav = totalav + setOfdata[i]
	}
	
	return (double) totalav / trips;
}

	if (totalav>=5)
	{
		printf("no discount to be applied");
	}







	