/*Write a C program to model a simple savings account for a customer. The program should
have functions to capture the following functionality:
• Lodge funds
• Withdraw funds
• Get the current Balance
• Get the total number of transactions
Provide test code in the main function to demonstrate the program. The program must
demonstrate the use of a global variable and a local static variable.*/

#include <stdio.h>

//declaring the global variables
int amount = 5000, lodge, withdraw, transactions;
int option, choice; 


int main ()
{
		printf("1. View current balance\n");
		printf("2. To lodge funds\n");
		printf("3. To withdraw funds\n");
		printf("4. Total number of transactions\n");
		
		printf("Please select one of the above options: \n");
		scanf("%d", &option);
		
	
		switch (option)
		{
			//printing the current balance
			case 1:
			printf ("your current balance is: %d", amount);
			break;
			//to lodge money into account
			case 2:
			printf ("Enter the amount to lodge: ");
			scanf("%d", &lodge);
			amount = amount + lodge;
			printf("Your current balance is: %d\n", amount);
			break;
			//to take money from account
			case 3:
			printf ("Enter the amount to withdraw: ");
			scanf("%d", &withdraw);
			//if the amount you want to take is greater than the balance, print error
			if (withdraw > amount)
			{
				printf("Insufficient Balance\n");
			}
			else
			{
				amount = amount - withdraw;
				printf("Please take your cash\n");
				printf("Your current balance is: %d\n", amount);
			}
			break;
			
			case 4:
			transactions = transactions + 1;
			printf("Your total number of transactions is: %d\n");
			break;
			
			default: ;
		}
	}
		
	
			

		
