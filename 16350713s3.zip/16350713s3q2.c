/*Write a C program which initially creates 2 two-dimensional integer arrays: arrayA and
arrayB. The size of the arrays should be equal and specified by user input. Each array
should be filled with random numbers between 5 and 100. The program should then create
new arrays for each of the following situations:
• An array containing the product of corresponding cells in arrayA and arrayB
• An array containing the sum of corresponding cells in arrayA and arrayB
• An array containing the average of corresponding cells in arrayA and arrayB
• An array containing the sum of corresponding rows in arrayA and arrayB
• An array containing the sum of corresponding columns in arrayA and arrayB
The program should print the contents of each array that was created. Finally, the program
should select and print a random cell value from arrayA.*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>


int main(void)
{
	int rows, columns;
	srand(time(NULL));
	
	printf("enter the number of rows: \n");
	scanf("%d", &rows);
	printf("enter the number of columns: \n");
	scanf("%d", &columns);
	
	int arrayA[rows][columns];
	int arrayB[rows][columns];
	int p[rows][columns];
	int r[rows];
	int i, j,
	
	
	//to fill the arrayA with a random number between 5 and 100
	for(i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			arrayA[i][j] = (5 + rand() % 95);
			
		}
	}
	//to fill the arrayB with a random number between 5 and 100
	for(i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{

			arrayB[i][j] = (5 + rand() % 95);
		}
	}
	//print the elements in arrayA
	printf("the elements of arrayA: \n");
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			printf("%d", arrayA[i][j]);
		}
		printf("\n");
	}
	//print the elements in arrayB
	printf("the elements of arrayB: \n");
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			printf("%d", arrayB[i][j]);
		}
		printf("\n");
	}
	
	//product of corresponding cells
	
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			p[i][j] = arrayA[i][j] * arrayB[i][j];
		}
	}
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			printf ("%d ", p[i][j]);
		}
		printf("\n");
	}
	
	//sum of corresponding cells
	
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			p[i][j] = arrayA[i][j] + arrayB[i][j];
		}
	}
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			printf ("%d ", p[i][j]);
		}
		printf("\n");
	}
	//average of corresponding cells
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			p[i][j] = arrayA[i][j] + arrayB[i][j]/2;
		}
	}
	for (i=0;i<rows;i++)
	{
		for(j=0;j<columns;j++)
		{
			printf ("%d ", p[i][j]);
		}
		printf("\n");
	}
	
	//sum of corresponding rows
	for (i=0;i<rows;i++)
	{
		r[i]=0;
		for(j=0;j<columns;j++)
		{
			r[i] = r[i] + arrayA[i][j] + arrayB[i][j];
		}
		printf("%d ", r[i]);
	}
	
	//sum of corresponding columns
	for (j=0;j<columns;j++)
	{
		r[j]=0;
		for(i=0;i<rows;i++)
		{
			r[j] = r[j] + arrayA[i][j]+arrayB[i][j];
		}
		printf("%d", r[j]);
	}
	
	
}


