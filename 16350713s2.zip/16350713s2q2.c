/*Write a function in C that calculates the day of the week based on a date. You should also
provide implementation to test the function. For example, it should indicate that 16th April
1967 is a Sunday. You can test it with your birthday. The algorithm that you need to
implement is Zeller’s Congruence Algorithm*/

#include <stdio.h>
#include <math.h>

int findday(int q, int m, int K);	//function prototype
int main (void)
{
	int day, month, year;
	int h;
	
	
	printf("enter date: dd/mm/yyyy: ");	//enter date in the format dd/mm/yyyy
	scanf("%d/%d/%d", &day, &month, &year);
	
	h = findday(day, month, year);	//calling the main
	//if the value of h is 0, the day is Saturday
	if (h == 0)
	{
		printf("Saturday\n");
	}
	//if the value of h is 1, the day is Sunday
	else if (h == 1)
	{
		printf("Sunday\n");
	}
	//if the value of h is 2, the day is Monday
	else if (h == 2)
	{
		printf("Monday\n");
	}
	//if the value of h is 3, the day is Tuesday
	else if (h == 3)
	{
		printf("Tuesday\n");
	}
	//if the value of h is 4, the day is Wednesday
	else if (h == 4)
	{
		printf("Wednesday\n");
	}
	//if the value of h is 5, the day is Thursday
	else if (h == 5)
	{
		printf("Thursday\n");
	}
	//if the value of h is 6, the day is Friday
	else if (h == 6)
	{
		printf("Friday\n");
	}
}

int findday(int q, int m, int K) //function definition

{
	int J, h, k;
	
	//q = day;
	//m = month;
	k = K % 100;
	J = K/100;
	//Zeller’s congruence
	h = q + floor ((13*(m+1))/5) + k + floor (k/4) + floor (J/4) + (5*J);
	h = h%7;
	

  return h;	//return the value of h
}






