/*Study the rules of the Thunderball lottery game from the UK National Lottery** and write a
program in C that selects a random set of numbers for the Thunderball draw. The C program
should give a different set of numbers each time. */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main (void)
{
	int i, j;
	int random;
	int thunderball;
	
	srand(time(NULL));	//randomize random number generator using current time
	
	printf("Your 5 numbers are: ");	//printing the numbers
	
	for(i=1;i<=5;i++)
	{
		random = 1 + rand() %39;	//picking a random number from 1 to 39
		printf("\n%d", random);
	}
	
	printf("\nYour thunderball is: ");	//printing the numbers
	
	
	
	thunderball = 1 + rand() %14;	//picking a random number from 1 to 14
	printf("\n%d", thunderball);
	
	
	
	return 0;
	
}
	
    