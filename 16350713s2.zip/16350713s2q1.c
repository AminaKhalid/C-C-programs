/*Write a function in C that calculates the volume of an ellipsoid when presented with all the
measurements needed to calculate it. You should also provide implementation to test the
function. The C program should calculate the volume of 4 ellipsoids by asking the user to
specify the required measurements.*/

#include <stdio.h>
#define PI 3.14159265359

double ellipsoid(double a, double b, double c);	//function prototype

int main (void)
{
	
	double a,b,c;
	int i;
	for (i=0;i<4;i++)	//asking the user to input values 4 times
	{
		printf("enter a value for measurement a: ");
		scanf("%lf", &a);
		printf("enter a value for measurement b: ");
		scanf("%lf", &b);
		printf("enter a value for measurement c: ");
		scanf("%lf", &c);
	
		printf ("the volume of the ellipsoid is: %lf \n\n", ellipsoid(a, b, c));
		
	}	
}

double ellipsoid(double a, double b, double c)	//function definition
{
	double volume;
	
	volume = (4.0/3.0)*PI*(a*b*c);	//formula for volume of ellipsoid
	
	return volume;
}