/*The greatest common divisor of integers x any y is the largest integer that evenly divides
both x and y. Write a recursive function gcd that returns the greatest common divisor of x
and y. The gcd of x and y is defined as follows: If y is equal to 0, then gcd (x,y) is x; otherwise
gcd (x,y) is gcd (y, x%y). */

#include <stdio.h>

int gcd(int x, int y); //function prototype

int main(void)
{
	int x, y;
	//to take input of values by user
	printf("Enter a value for x: ");
	scanf("%d", &x);
	
	printf("Enter a value for y: ");
	scanf("%d", &y);
	//display result
	printf("The greatest common divisor is: %d", gcd(x,y));
}
	//gcd function
int gcd(int x, int y)
{
	if (y == 0) //if y is equal to 0 then gcd (x,y) is x
	{
		return x; 
	}
	else		//otherwise gcd (x,y) is gcd (y, x%y)
	{
		return gcd(y, x%y);		//x mod y is returned to the function
	}

}	
